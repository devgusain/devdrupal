(function ($, Drupal) {
  'use strict';

  window.FontAwesomeConfig = {
    searchPseudoElements: true
  }
})(jQuery, Drupal);
