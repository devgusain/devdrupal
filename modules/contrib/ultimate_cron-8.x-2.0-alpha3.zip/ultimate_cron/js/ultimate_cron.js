jQuery(document).ready(function ($) {
  'use strict';

  /*
  setInterval(function() {
    $("#ctools-export-ui-list-items-reload").click();
  }, 1000);
  */
});
