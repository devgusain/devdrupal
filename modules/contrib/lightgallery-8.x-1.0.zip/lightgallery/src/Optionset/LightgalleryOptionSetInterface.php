<?php

namespace Drupal\lightgallery\Optionset;


interface LightgalleryOptionSetInterface {
  /**
   * Returns the optionset.
   */
  public function get();
}