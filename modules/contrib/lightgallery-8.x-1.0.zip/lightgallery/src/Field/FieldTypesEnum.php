<?php

namespace Drupal\lightgallery\Field;


abstract class FieldTypesEnum {

  const TEXTFIELD = 'textfield';
  const SELECT = 'select';
  const CHECKBOX = 'checkbox';

}